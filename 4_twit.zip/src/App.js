import AppRouter from 'AppRouter';
import { useEffect, useState } from 'react';
import { authService } from 'fbase';
import { onAuthStateChanged } from "firebase/auth";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(authService.currentUser);
  

  const [userObj, setUserObj] = useState(null);

  useEffect(() => {
    onAuthStateChanged(authService, (user) => {
      if (user) {
        setIsLoggedIn(user)
        setUserObj(user)
      } else {
        setIsLoggedIn(false)
      }
    });
    
  },[]);

  return (
    <>
    <AppRouter isLoggedIn = {isLoggedIn} userObj={userObj}/>
    <footer>&copy; {new Date().getFullYear()} Twit app</footer>
    </>
  );
}

export default App;

//*********************************************************************************
//*********************  useCallBack 함수 나중에 다 붙여주기  *********************
//*********************************************************************************