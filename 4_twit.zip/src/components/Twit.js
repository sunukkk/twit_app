import React, { useState } from 'react'
import { doc, deleteDoc, updateDoc } from "firebase/firestore";
import { db, storage } from 'fbase';
import { ref, deleteObject } from "firebase/storage";


function Twit(props) {
  const {twitObj: {text,id,attachmentUrl}, isOwner} = props;
  const [editing, setEditing] = useState(false)  
  const [newTwit, setNewTwit] = useState(text)
  
  const onDeleteClick = async () => {
    const ok = window.confirm("삭제하시겠습니까?")
    if (ok) {
      await deleteDoc(doc(db, "twits", `/${id}`));
      if (attachmentUrl !== "") {
        const desertRef = ref(storage, attachmentUrl);
        await deleteObject(desertRef);
      }
    }
  };
  
  const toggleEditing = () => setEditing((prev) => !prev)
  
  const onChange = e => {
    const {target:{value}} = e
    setNewTwit(value);
  }

  const onSubmit = async(e) =>{
    e.preventDefault();
    const newTwitRef = doc(db, "twits", id);

  await updateDoc(newTwitRef, {
  text: newTwit,
  createdAt: Date.now(),
  });
setEditing(false);
  }

  return (
  
    <div>
      {editing ? (
        <>
          <form onSubmit={onSubmit}>
            <input type="text" onChange={onChange} value={newTwit} required />
            <input type="submit" value = "Update twit" />
          </form>
          <button onClick={toggleEditing}>Cancel</button>
        </>
      ) : (
        <>
          <h4>{text}</h4>
          <img src={attachmentUrl} width="50" height="50" alt="" />
          {isOwner && (
            <>
              <button onClick={onDeleteClick}>Delete Twit</button>
              <button onClick={toggleEditing}>Edit Twit</button>
            </>
          )}
        </>
      )}
    </div>
  )
}

export default Twit
