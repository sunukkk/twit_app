import React, { useEffect, useState } from 'react'
import { collection, addDoc, getDocs, onSnapshot, query, orderBy } from "firebase/firestore";
import { db, storage } from 'fbase';
import Twit from 'components/Twit';
import { v4 as uuidv4 } from 'uuid';
import { ref, uploadString, getDownloadURL } from "firebase/storage";

function Home({userObj}) {
  console.log(userObj)
  
  const [twit, setTwit] = useState("");
  const [twits, setTwits] = useState([]);
  const [attachment, setAttachment] = useState("")

  useEffect(() => {
    const q = query(collection(db, "twits"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const newArray = [];
      querySnapshot.forEach((doc) => {
        newArray.push({ ...doc.data(), id: doc.id });
      });
      setTwits(newArray);
    });
    return () => unsubscribe();
  },[]);

  const onChange = (e) =>{
    e.preventDefault();
    const {target: {value}} = e;
    setTwit(value);
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    
    try {
      let attachmentUrl = "";  
      if(attachment !== ""){
        const storageRef = ref(storage, `${userObj.uid}/${uuidv4()}`);
        const response = await uploadString(storageRef, attachment, 'data_url'); 
        console.log('response ->>', response)
        attachmentUrl = await getDownloadURL(ref(storage, response.ref));
      }
      const docRef = await addDoc(collection(db, "twits"), {
        text: twit,
        createdAt: Date.now(),
        creatorId: userObj.uid,
        attachmentUrl
      });
      console.log("Document written with ID: ", docRef.id);
    } catch (e) {
      console.error("Error adding document: ", e);
    }
    setTwit("");
    setAttachment("");
  }

  const onFilechange = (e) =>{
    console.log('e->',e);
    const {target: {files}} = e;

    const theFile = files[0]
    console.log('theFile ->', theFile)

    const reader = new FileReader();
    reader.onloadend = (finishedEvent) =>{
      console.log('f.e =>', finishedEvent)
      const {currentTarget:{result}} = finishedEvent;
      setAttachment(result);
    }
    reader.readAsDataURL(theFile)
  }

  const onclearAttachment = () =>{
    setAttachment("");
  }
  return (
    <>
    <form onSubmit={onSubmit}>
      <input type="text" placeholder="What's on yoru mind?" value={twit} onChange={onChange}/>
      <input type="file" accept='image/*' onChange={onFilechange}/>
      <input type="submit" value = 'Twit'/>
      {attachment &&(
        <div>
          <img src={attachment} width="50" height ="50" alt=""/>
          <button onClick={onclearAttachment}>Remove</button>
        </div>
      )}
    </form>
    <div>
      {twits.map(twit => (
      // <div key = {twit.id}>
      //    <h4>{twit.text}</h4>
      // </div>
      
      <Twit key={twit.id} twitObj={twit} isOwner={twit.creatorId === userObj.uid}/>
      ))}
    </div>
    </>
  )
}

export default Home

